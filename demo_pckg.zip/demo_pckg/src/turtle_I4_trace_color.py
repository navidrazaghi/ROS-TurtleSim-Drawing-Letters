#!/usr/bin/python3

import rospy
from turtlesim.srv import SetPen

if __name__ == '__main__':
    rospy.init_node('turtle_pen_I4')
    # Create a service proxy for the set_pen service
    rospy.wait_for_service('/turtle6/set_pen')
    set_pen = rospy.ServiceProxy('/turtle6/set_pen', SetPen)
    # Set the pen color and width
    set_pen(255, 255, 0, 5, 0)
    rospy.spin()  # Keep the node running
     