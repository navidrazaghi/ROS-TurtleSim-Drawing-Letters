#!/usr/bin/python3

import rospy
from turtlesim.srv import Kill

if __name__ == '__main__':
    rospy.init_node('turtle_killer')
    rospy.wait_for_service('/kill')
    kill_turtle = rospy.ServiceProxy('/kill', Kill)
    # Call the kill service with the name of the turtle as a string
    response = kill_turtle('turtle1')
    

