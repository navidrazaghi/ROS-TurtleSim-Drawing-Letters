#!/usr/bin/python3
import rospy
from turtlesim.srv import SetPen
import math
from turtlesim.srv import TeleportAbsolute
from geometry_msgs.msg import Twist
from turtlesim.srv import Spawn

def move_turtle(turtle_name, linear_vel,vx,vy,desired_distance):
    turtle_pub = rospy.Publisher('/{}/cmd_vel'.format(turtle_name), Twist, queue_size=10)
    print('/{}/cmd_vel'.format(turtle_name))
    twist_msg = Twist()
    twist_msg.linear.x = linear_vel*vx
    twist_msg.linear.y = linear_vel*vy
    x_vel = linear_vel*vx
    y_vel = linear_vel*vy
    twist_msg.linear.z = 0
    twist_msg.angular.x = 0
    twist_msg.angular.y = 0
    twist_msg.angular.z = 0
    rate = rospy.Rate(10)
    current_distance = 0 
    linear_velocity = math.sqrt(x_vel**2 + y_vel**2)
    t0 = rospy.Time().now().to_sec()
    while current_distance <= desired_distance : 
        turtle_pub.publish(twist_msg)
        t1 = rospy.Time().now().to_sec() - t0
        current_distance = linear_velocity * t1
        rate.sleep()
if __name__ == '__main__':
    rospy.init_node('Turtle_move_I')
    rospy.wait_for_service('/spawn')
    spawn_turtle = rospy.ServiceProxy('/spawn', Spawn)
    spawn_turtle(2.5, 4, 0.0, "turtle2")
    move_turtle("turtle2", 0.5,-1,0,0.5)
    move_turtle("turtle2", 1,1,0,0.03)
    move_turtle("turtle2", 2,0,1,2)
    move_turtle("turtle2", 1,1,0,0.1)
    move_turtle("turtle2", 0.5,-1,0,0.1)

