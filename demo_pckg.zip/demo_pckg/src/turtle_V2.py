#!/usr/bin/python3
import rospy
import math
from geometry_msgs.msg import Twist
from turtlesim.srv import SetPen
from turtlesim.srv import Spawn

def move_turtle(turtle_name, linear_vel,vx,vy,desired_distance):
    turtle_pub = rospy.Publisher('/{}/cmd_vel'.format(turtle_name), Twist, queue_size=10)
    print('/{}/cmd_vel'.format(turtle_name))
    twist_msg = Twist()
    x_vel = linear_vel*vx
    y_vel = linear_vel*vy
    twist_msg.linear.x = x_vel
    twist_msg.linear.y = y_vel
    twist_msg.linear.z = 0
    linear_velocity = math.sqrt(x_vel**2 + y_vel**2)
    twist_msg.angular.x = 0
    twist_msg.angular.y = 0
    twist_msg.angular.z = 0
    rate = rospy.Rate(10)
    t0 = rospy.Time().now().to_sec()
    current_distance = 0 
    while current_distance <= desired_distance : 
        turtle_pub.publish(twist_msg)
        t1 = rospy.Time().now().to_sec() - t0
        current_distance = linear_velocity * t1
        rate.sleep()
    twist_msg.linear.x = 0
    twist_msg.linear.y = 0
    turtle_pub.publish(twist_msg)

if __name__ == '__main__':
    rospy.init_node('Turtle_move_V2')
    rospy.wait_for_service('/spawn')
    spawn_turtle = rospy.ServiceProxy('/spawn', Spawn)
    spawn_turtle(9, 6.2, 0.0, "turtle7")
    move_turtle("turtle7", 2,1,-2,3)
    move_turtle("turtle7", 0.2,1,2,2)